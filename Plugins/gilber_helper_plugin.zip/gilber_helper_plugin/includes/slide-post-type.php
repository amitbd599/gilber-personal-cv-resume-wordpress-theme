<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

/**
 * Register slide post type
 */
if ( ! function_exists( 'vlthemes_slide_register_custom_post' ) ) {

	function vlthemes_slide_register_custom_post() {

		$labels = array(
			'name' => esc_html__( 'Slides', 'vlthemes' ),
			'singular_name' => esc_html__( 'Slide', 'vlthemes' ),
			'add_new' => esc_html__( 'Add New Slide', 'vlthemes' ),
			'add_new_item' => esc_html__( 'Add New Slide', 'vlthemes' ),
			'edit_item' => esc_html__( 'Edit Slide', 'vlthemes' ),
			'new_item' => esc_html__( 'New Slide', 'vlthemes' ),
			'view_item' => esc_html__( 'View Slide', 'vlthemes' ),
			'search_items' => esc_html__( 'Search Slides', 'vlthemes' ),
			'not_found' => esc_html__( 'No Slide Found', 'vlthemes' ),
			'not_found_in_trash' => esc_html__( 'No slide found in Trash', 'vlthemes' )
		);

		$args = array(
			'labels' => $labels,
			'supports' => array( 'title', 'editor', 'elementor' ),
			'hierarchical' => false,
			'public' => false,
			'publicly_queryable' => false,
			'show_ui' => true,
			'show_in_menu' => true,
			'menu_position' => 5,
			'menu_icon' => 'dashicons-images-alt2',
			'show_in_admin_bar' => true,
			'show_in_nav_menus' => true,
			'can_export' => true,
			'has_archive' => false,
			'exclude_from_search' => true,
			'publicly_queryable' => true,
			'rewrite' => false,
			'capability_type' => 'page',
		);

		register_post_type( 'slide', $args );

	}

	add_action( 'init', 'vlthemes_slide_register_custom_post', 0 );

}