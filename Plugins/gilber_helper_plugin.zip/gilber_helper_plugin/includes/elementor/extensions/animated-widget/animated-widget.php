<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! class_exists( 'VLThemes_Animated_Widget' ) ) {

	class VLThemes_Animated_Widget {

		public function __construct() {
			add_action( 'elementor/element/common/_section_style/after_section_end', [ $this, 'register_controls' ], 10 );
			add_action( 'elementor/widget/before_render_content', [ $this, 'before_render' ] );
		}

		public function get_name() {
			return 'vlt-animated-widget';
		}

		public function register_controls( $element ) {

			$element->start_controls_section(
				'vlt_animated_widget', [
					'label' => esc_html__( 'Animated Widget', 'vlthemes' ),
					'tab' => Controls_Manager::TAB_ADVANCED,
				]
			);

			$element->add_control(
				'vlt_animated_widget_animation', [
					'label' => esc_html__( 'Animation Name', 'vlthemes' ),
					'type' => Controls_Manager::SELECT,
					'options' => [
						'none' => 'None',
						'bounce' => 'bounce',
						'flash' => 'flash',
						'pulse' => 'pulse',
						'rubberBand' => 'rubberBand',
						'shake' => 'shake',
						'headShake' => 'headShake',
						'swing' => 'swing',
						'tada' => 'tada',
						'wobble' => 'wobble',
						'jello' => 'jello',
						'bounceIn' => 'bounceIn',
						'bounceInDown' => 'bounceInDown',
						'bounceInLeft' => 'bounceInLeft',
						'bounceInRight' => 'bounceInRight',
						'bounceInUp' => 'bounceInUp',
						'bounceOut' => 'bounceOut',
						'bounceOutDown' => 'bounceOutDown',
						'bounceOutLeft' => 'bounceOutLeft',
						'bounceOutRight' => 'bounceOutRight',
						'bounceOutUp' => 'bounceOutUp',
						'fadeIn' => 'fadeIn',
						'fadeInDown' => 'fadeInDown',
						'fadeInDownSm' => 'fadeInDownSm',
						'fadeInDownBig' => 'fadeInDownBig',
						'fadeInLeft' => 'fadeInLeft',
						'fadeInLeftSm' => 'fadeInLeftSm',
						'fadeInLeftBig' => 'fadeInLeftBig',
						'fadeInRight' => 'fadeInRight',
						'fadeInRightSm' => 'fadeInRightSm',
						'fadeInRightBig' => 'fadeInRightBig',
						'fadeInUp' => 'fadeInUp',
						'fadeInUpSm' => 'fadeInUpSm',
						'fadeInUpBig' => 'fadeInUpBig',
						'fadeOut' => 'fadeOut',
						'fadeOutDown' => 'fadeOutDown',
						'fadeOutDownBig' => 'fadeOutDownBig',
						'fadeOutLeft' => 'fadeOutLeft',
						'fadeOutLeftBig' => 'fadeOutLeftBig',
						'fadeOutRight' => 'fadeOutRight',
						'fadeOutRightBig' => 'fadeOutRightBig',
						'fadeOutUp' => 'fadeOutUp',
						'fadeOutUpBig' => 'fadeOutUpBig',
						'flipInX' => 'flipInX',
						'flipInY' => 'flipInY',
						'flipOutX' => 'flipOutX',
						'flipOutY' => 'flipOutY',
						'lightSpeedIn' => 'lightSpeedIn',
						'lightSpeedOut' => 'lightSpeedOut',
						'rotateIn' => 'rotateIn',
						'rotateInDownLeft' => 'rotateInDownLeft',
						'rotateInDownRight' => 'rotateInDownRight',
						'rotateInUpLeft' => 'rotateInUpLeft',
						'rotateInUpRight' => 'rotateInUpRight',
						'rotateOut' => 'rotateOut',
						'rotateOutDownLeft' => 'rotateOutDownLeft',
						'rotateOutDownRight' => 'rotateOutDownRight',
						'rotateOutUpLeft' => 'rotateOutUpLeft',
						'rotateOutUpRight' => 'rotateOutUpRight',
						'hinge' => 'hinge',
						'jackInTheBox' => 'jackInTheBox',
						'rollIn' => 'rollIn',
						'rollOut' => 'rollOut',
						'zoomIn' => 'zoomIn',
						'zoomInDown' => 'zoomInDown',
						'zoomInLeft' => 'zoomInLeft',
						'zoomInRight' => 'zoomInRight',
						'zoomInUp' => 'zoomInUp',
						'zoomOut' => 'zoomOut',
						'zoomOutDown' => 'zoomOutDown',
						'zoomOutLeft' => 'zoomOutLeft',
						'zoomOutRight' => 'zoomOutRight',
						'zoomOutUp' => 'zoomOutUp',
						'slideInDown' => 'slideInDown',
						'slideInLeft' => 'slideInLeft',
						'slideInRight' => 'slideInRight',
						'slideInUp' => 'slideInUp',
						'slideOutDown' => 'slideOutDown',
						'slideOutLeft' => 'slideOutLeft',
						'slideOutRight' => 'slideOutRight',
						'slideOutUp' => 'slideOutUp',
						'heartBeat' => 'heartBeat',
					],
					'default' => 'none',
					'frontend_available' => true,
					'render_type' => 'none',
				]
			);

			$element->add_control(
				'vlt_animated_widget_duration', [
					'label' => esc_html__( 'Animation Duration', 'vlthemes' ),
					'description' => esc_html__( 'Change the animation duration', 'vlthemes' ),
					'type' => Controls_Manager::NUMBER,
					'default' => '',
					'min' => 0,
					'step' => 50,
					'condition' => [
						'vlt_animated_widget_animation!' => 'none',
					],
					'frontend_available' => true,
					'render_type' => 'none',
				]
			);

			$element->add_control(
				'vlt_animated_widget_delay', [
					'label' => esc_html__( 'Animation Delay', 'vlthemes' ),
					'description' => esc_html__( 'Delay before the animation starts', 'vlthemes' ),
					'type' => Controls_Manager::NUMBER,
					'default' => '',
					'min' => 0,
					'step' => 50,
					'condition' => [
						'vlt_animated_widget_animation!' => 'none',
					],
				]
			);

			$element->end_controls_section();

		}

		public function before_render( $element ) {

			$settings = $element->get_settings_for_display();

			if ( $settings[ 'vlt_animated_widget_animation' ] != 'none' ) {

				$style = '';

				if ( $settings[ 'vlt_animated_widget_duration' ] ) {
					$style .= ' --animate-duration: ' . $settings[ 'vlt_animated_widget_duration' ] . 'ms;';
				}

				if ( $settings[ 'vlt_animated_widget_delay' ] ) {
					$style .= ' --animate-delay: ' . $settings[ 'vlt_animated_widget_delay' ] . 'ms;';
				}

				$element->add_render_attribute( '_wrapper', [
					'class' => 'vlt-animate-element',
					'data-animation-name' => $settings[ 'vlt_animated_widget_animation' ],
					'style' => $style
 				] );

			}

		}


	}

}
