<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Widget_VLThemes_Slider_Controls extends Widget_Base {

	public function get_name() {
		return 'vlt-slider-controls';
	}

	public function get_title() {
		return esc_html__( 'Slider Controls', 'vlthemes' );
	}

	public function get_icon() {
		return 'eicon-post-navigation vlthemes-badge';
	}

	public function get_categories() {
		return [ 'vlthemes-elements' ];
	}

	public function get_keywords() {
		return [ 'navigation', 'slider', 'controls' ];
	}

	protected function _register_controls() {

		$first_level = 0;

		// ANCHOR
		$this->start_controls_section(
			'section_' . $first_level++, [
				'label' => esc_html__( 'Slider Controls', 'vlthemes' ),
			]
		);

		$this->add_control(
			'style', [
				'label' => esc_html__( 'Arrows Style', 'vlthemes' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style-1',
				'options' => [
					'style-1' => esc_html__( 'Style 1', 'vlthemes' ),
					'style-2' => esc_html__( 'Style 2', 'vlthemes' )
				]
			]
		);

		$this->add_control(
			'navigation', [
				'label' => esc_html__( 'Navigation', 'vlthemes' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'both',
				'options' => [
					'both' => esc_html__( 'Both', 'vlthemes' ),
					'arrows' => esc_html__( 'Arrows', 'vlthemes' ),
					'dots' => esc_html__( 'Dots', 'vlthemes' )
				],
			]
		);

		$this->end_controls_section();

		// ANCHOR
		$this->start_controls_section(
			'section_' . $first_level++, [
				'label' => esc_html__( 'Style', 'vlthemes' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'alignment', [
				'label' => esc_html__( 'Alignment', 'vlthemes' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'vlthemes' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'vlthemes' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'vlthemes' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'slider-controls', [
			'class' => [
				'vlt-slider-controls',
				'vlt-slider-controls--' . $settings[ 'style' ]
			]
		] );

		// prepend slider controls
		$show_dots = ( in_array( $settings[ 'navigation' ], [ 'dots', 'both' ] ) );
		$show_arrows = ( in_array( $settings[ 'navigation' ], [ 'arrows', 'both' ] ) );

		?>

		<div <?php echo $this->get_render_attribute_string( 'slider-controls' ); ?>>

			<?php if ( $show_dots ) : ?>

				<div class="vlt-swiper-pagination"></div>

			<?php endif; ?>

			<?php if ( $show_arrows ) : ?>

				<div class="vlt-swiper-button-prev">

					<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 45"><defs/><path fill="currentColor" fill-rule="evenodd" d="M1.36413 22.5795L24 43.9524l-.7271.6865L.272896 22.9223l.383716-.3623-.362754-.3367L23.0941.319721l.733.680233L1.36413 22.5795z" clip-rule="evenodd"/></svg>

				</div>

			<?php endif; ?>

			<?php if ( $show_arrows ) : ?>

				<div class="vlt-swiper-button-next">

					<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 45"><defs/><path fill-rule="evenodd" clip-rule="evenodd" d="M22.6359 22.3728L0 1.00001.727101.313477 23.7271 22.0301l-.3837.3623.3627.3367L.905866 44.6327l-.732997-.6803L22.6359 22.3728z" fill="currentColor"/></svg>

				</div>

			<?php endif; ?>

		</div>

		<?php

	}

}