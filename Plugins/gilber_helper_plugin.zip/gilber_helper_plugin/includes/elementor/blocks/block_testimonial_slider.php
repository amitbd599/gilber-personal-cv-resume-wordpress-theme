<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Widget_VLThemes_Testimonial_Slider extends Widget_Base {

	public function get_name() {
		return 'vlt-testimonial-slider';
	}

	public function get_title() {
		return esc_html__( 'Testimonial Slider', 'vlthemes' );
	}

	public function get_icon() {
		return 'eicon-testimonial vlthemes-badge';
	}

	public function get_categories() {
		return [ 'vlthemes-elements' ];
	}

	public function get_keywords() {
		return [ 'testimonial', 'review', 'blockquote', 'slider' ];
	}

	protected function _register_controls() {

		$first_level = 0;


		// ANCHOR
		$this->start_controls_section(
			'section_' . $first_level++, [
				'label' => esc_html__( 'Testimonials', 'vlthemes' ),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'name', [
				'label' => esc_html__( 'Name', 'vlthemes' ),
				'type' => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'function', [
				'label' => esc_html__( 'Function', 'vlthemes' ),
				'type' => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'text', [
				'label' => esc_html__( 'Text', 'vlthemes' ),
				'type' => Controls_Manager::WYSIWYG,
			]
		);

		$this->add_control(
			'items', [
				'label' => esc_html__( 'Items', 'vlthemes' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ name }}}',
			]
		);

		$this->add_control(
			'navigation_anchor', [
				'label' => esc_html__( 'Navigation Anchor', 'vlthemes' ),
				'description' => esc_html__( 'Enter class / identifier that the navigation has.', 'vlthemes' ),
				'type' => Controls_Manager::TEXT,
				'separator' => 'before',
			]
		);

		$this->end_controls_section();

		// ANCHOR
		$this->start_controls_section(
			'section_' . $first_level++, [
				'label' => esc_html__( 'Content', 'vlthemes' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_color', [
				'label' => esc_html__( 'Text Color', 'vlthemes' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vlt-testimonial__text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), [
				'name' => 'text_typography',
				'selector' => '{{WRAPPER}} .vlt-testimonial__text',
			]
		);

		$this->end_controls_section();

		// ANCHOR
		$this->start_controls_section(
			'section_' . $first_level++, [
				'label' => esc_html__( 'Metas', 'vlthemes' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'meta_spacing', [
				'label' => esc_html__( 'Spacing', 'vlthemes' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .vlt-testimonial__meta' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'heading_' . $first_level++, [
				'label' => esc_html__( 'Name', 'vlthemes' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'name_color', [
				'label' => esc_html__( 'Text Color', 'vlthemes' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vlt-testimonial__name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), [
				'name' => 'name_typography',
				'selector' => '{{WRAPPER}} .vlt-testimonial__name',
			]
		);

		$this->add_control(
			'heading_' . $first_level++, [
				'label' => esc_html__( 'Function', 'vlthemes' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'function_color', [
				'label' => esc_html__( 'Text Color', 'vlthemes' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vlt-testimonial__function' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), [
				'name' => 'function_typography',
				'selector' => '{{WRAPPER}} .vlt-testimonial__function',
			]
		);

		$this->add_responsive_control(
			'function_margin', [
				'label' => esc_html__( 'Margin', 'vlthemes' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', '%' ],
				'selectors' => [
					'{{WRAPPER}} .vlt-testimonial__function' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( [
			'testimonial-slider' => [
				'class' => 'vlt-testimonial-slider',
				'data-navigation-anchor' => $settings[ 'navigation_anchor' ]
			]
		] );

	?>

	<div <?php echo $this->get_render_attribute_string( 'testimonial-slider' ); ?>>

		<div class="swiper-container">

			<div class="swiper-wrapper">

				<?php

					foreach ( $settings[ 'items' ] as $item ) {

						echo '<div class="swiper-slide">';

							echo '<div class="vlt-testimonial">';

								if ( $item[ 'text' ] ) :
									echo '<div class="vlt-testimonial__text">';
									echo $item[ 'text' ];
									echo '</div>';
								endif;

								echo '<div class="vlt-testimonial__meta">';

									if ( $item[ 'name' ] ) :
										echo '<h5 class="vlt-testimonial__name">';
										echo $item[ 'name' ];
										echo '</h5>';
									endif;

									if ( $item[ 'function' ] ) :
										echo '<div class="vlt-testimonial__function">';
										echo $item[ 'function' ];
										echo '</div>';
									endif;

								echo '</div>';

							echo '</div>';

						echo '</div>';

					}

				?>

			</div>

		</div>

	</div>

	<?php

	}

}