<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Widget_VLThemes_Pullquote extends Widget_Base {

	public function get_name() {
		return 'vlt-pullquote';
	}

	public function get_title() {
		return esc_html__( 'Pullquote', 'vlthemes' );
	}

	public function get_icon() {
		return 'eicon-blockquote vlthemes-badge';
	}

	public function get_categories() {
		return [ 'vlthemes-elements' ];
	}

	public function get_keywords() {
		return [ 'quote', 'pullquote' ];
	}

	protected function _register_controls() {

		$first_level = 0;

		// ANCHOR
		$this->start_controls_section(
			'section_' . $first_level++, [
				'label' => esc_html__( 'Pullquote', 'vlthemes' ),
			]
		);

		$this->add_control(
			'text', [
				'label' => esc_html__( 'Text', 'vlthemes' ),
				'type' => Controls_Manager::WYSIWYG,
			]
		);

		$this->add_control(
			'name', [
				'label' => esc_html__( 'Name', 'vlthemes' ),
				'type' => Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'function', [
				'label' => esc_html__( 'Function', 'vlthemes' ),
				'type' => Controls_Manager::TEXT,
			]
		);

		$this->end_controls_section();

		// ANCHOR
		$this->start_controls_section(
			'section_' . $first_level++, [
				'label' => esc_html__( 'Content', 'vlthemes' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_color', [
				'label' => esc_html__( 'Text Color', 'vlthemes' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vlt-pullquote__text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), [
				'name' => 'text_typography',
				'selector' => '{{WRAPPER}} .vlt-pullquote__text',
			]
		);

		$this->end_controls_section();

		// ANCHOR
		$this->start_controls_section(
			'section_' . $first_level++, [
				'label' => esc_html__( 'Metas', 'vlthemes' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'meta_spacing', [
				'label' => esc_html__( 'Spacing', 'vlthemes' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .vlt-pullquote__meta' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'heading_' . $first_level++, [
				'label' => esc_html__( 'Name', 'vlthemes' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'name_color', [
				'label' => esc_html__( 'Text Color', 'vlthemes' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vlt-pullquote__name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), [
				'name' => 'name_typography',
				'selector' => '{{WRAPPER}} .vlt-pullquote__name',
			]
		);

		$this->add_control(
			'heading_' . $first_level++, [
				'label' => esc_html__( 'Function', 'vlthemes' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'function_color', [
				'label' => esc_html__( 'Text Color', 'vlthemes' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vlt-pullquote__function' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), [
				'name' => 'function_typography',
				'selector' => '{{WRAPPER}} .vlt-pullquote__function',
			]
		);

		$this->add_responsive_control(
			'function_margin', [
				'label' => esc_html__( 'Margin', 'vlthemes' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', '%' ],
				'selectors' => [
					'{{WRAPPER}} .vlt-pullquote__function' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'pullquote', 'class', 'vlt-pullquote' );

		?>

		<div <?php echo $this->get_render_attribute_string( 'pullquote' ); ?>>

			<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 75 75"><defs></defs><path fill="currentColor" d="M25 0C16.9271 0 10.7422 2.14844 6.44531 6.44531 2.14844 10.7422 0 16.9271 0 25v50h31.25V25H12.5c0-4.4271.9766-7.6172 2.9297-9.5703C17.3828 13.4766 20.5729 12.5 25 12.5V0zm43.75 0c-8.0729 0-14.2578 2.14844-18.5547 6.44531C45.8984 10.7422 43.75 16.9271 43.75 25v50H75V25H56.25c0-4.4271.9766-7.6172 2.9297-9.5703C61.1328 13.4766 64.3229 12.5 68.75 12.5V0z"></path></svg>

			<?php if ( $settings[ 'text' ] ) : ?>
				<div class="vlt-pullquote__text"><?php echo $settings[ 'text' ]; ?></div>
			<?php endif; ?>

			<div class="vlt-pullquote__meta">

				<?php if ( $settings[ 'name' ] ) : ?>
					<h5 class="vlt-pullquote__name"><?php echo $settings[ 'name' ]; ?></h5>
				<?php endif; ?>

				<?php if ( $settings[ 'function' ] ) : ?>
					<div class="vlt-pullquote__function"><?php echo $settings[ 'function' ]; ?></div>
				<?php endif; ?>

			</div>

		</div>

		<?php

	}

}