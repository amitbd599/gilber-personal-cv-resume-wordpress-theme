<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Widget_VLThemes_Simple_Image extends Widget_Base {

	public function get_name() {
		return 'vlt-simple-image';
	}

	public function get_title() {
		return esc_html__( 'Simple Image', 'vlthemes' );
	}

	public function get_icon() {
		return 'eicon-image vlthemes-badge';
	}

	public function get_categories() {
		return [ 'vlthemes-elements' ];
	}

	public function get_keywords() {
		return [ 'simple', 'photo', 'image' ];
	}

	protected function _register_controls() {

		$first_level = 0;

		// ANCHOR
		$this->start_controls_section(
			'section_' . $first_level++, [
				'label' => esc_html__( 'Simple Image', 'vlthemes' ),
			]
		);

		$this->add_control(
			'image', [
				'label' => esc_html__( 'Image', 'vlthemes' ),
				'type' => Controls_Manager::MEDIA,
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(), [
				'name' => 'image', // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
			]
		);

		$this->add_control(
			'mask', [
				'label' => esc_html__( 'Mask', 'vlthemes' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		// ANCHOR
		$this->start_controls_section(
			'section_' . $first_level++, [
				'label' => esc_html__( 'Image Mask', 'vlthemes' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'mask' => 'yes',
				],
			]
		);

		$this->add_control(
			'mask_background_color', [
				'label' => esc_html__( 'Background Color', 'vlthemes' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .inside ' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'simple-image', 'class', 'vlt-simple-image' );

		?>

		<div <?php echo $this->get_render_attribute_string( 'simple-image' ); ?>>


			<?php if ( $settings[ 'mask' ] == 'yes' ) : ?>

				<div class="vlt-simple-image__mask"><div class="inside"></div></div>

			<?php endif; ?>

			<?php if ( $settings[ 'image' ][ 'url' ] ) : ?>

				<?php

					echo wp_get_attachment_image( $settings[ 'image' ][ 'id' ], $settings[ 'image_size' ], false, [
						'loading' => 'lazy'
					] );

				?>

			<?php endif; ?>

		</div>

		<?php

	}

}