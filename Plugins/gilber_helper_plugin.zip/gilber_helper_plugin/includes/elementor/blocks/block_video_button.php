<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Widget_VLThemes_Video_Button extends Widget_Base {

	public function get_name() {
		return 'vlt-video-button';
	}

	public function get_title() {
		return esc_html__( 'Video Button', 'vlthemes' );
	}

	public function get_icon() {
		return 'eicon-play vlthemes-badge';
	}

	public function get_categories() {
		return [ 'vlthemes-elements' ];
	}

	public function get_keywords() {
		return [ 'video', 'play', 'popup', 'button', 'fancybox' ];
	}

	protected function _register_controls() {

		$first_level = 0;

		// ANCHOR
		$this->start_controls_section(
			'section_' . $first_level++, [
				'label' => esc_html__( 'Video Button', 'vlthemes' ),
			]
		);

		$this->add_control(
			'video_type', [
				'label' => esc_html__( 'Video Type', 'vlthemes' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'vimeo',
				'options' => [
					'youtube'=> esc_html__( 'YouTube', 'vlthemes' ),
					'vimeo'=> esc_html__( 'Vimeo', 'vlthemes' ),
				]
			]
		);

		$this->add_control(
			'caption', [
				'label' => esc_html__( 'Caption', 'vlthemes' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true
			]
		);

		$this->add_control(
			'video_url', [
				'label' => esc_html__( 'Video URL', 'vlthemes' ),
				'type' => Controls_Manager::TEXT,
				'input_type' => 'url',
				'label_block' => true,
				'default' => 'https://vimeo.com/367945766',
			]
		);

		$this->add_control(
			'start_time', [
				'label' => esc_html__( 'Start Time', 'vlthemes' ),
				'description' => esc_html__( 'Specify a start time (in seconds)', 'vlthemes' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 0,
				'condition' => [
					'video_type' => 'youtube'
				],
				'separator' => 'before'
			]
		);

		$this->add_control(
			'end_time', [
				'label' => esc_html__( 'End Time', 'vlthemes' ),
				'description' => esc_html__( 'Specify an end time (in seconds)', 'vlthemes' ),
				'type' => Controls_Manager::NUMBER,
				'condition' => [
					'video_type' => 'youtube'
				]
			]
		);

		$this->add_control(
			'auto_play', [
				'label' => esc_html__( 'Auto Play', 'vlthemes' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'vlthemes' ),
				'label_off' => esc_html__( 'No', 'vlthemes' ),
				'default' => 'yes',
			]
		);

		$this->add_control(
			'mute', [
				'label' => esc_html__( 'Mute', 'vlthemes' ),
				'description' => esc_html__( 'This will play the video muted', 'vlthemes' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'vlthemes' ),
				'label_off' => esc_html__( 'No', 'vlthemes' ),
				'default' => 'no',
			]
		);

		$this->add_control(
			'loop', [
				'label' => esc_html__( 'Loop', 'vlthemes' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'vlthemes' ),
				'label_off' => esc_html__( 'No', 'vlthemes' ),
				'default' => 'no',
			]
		);

		$this->add_control(
			'show_controls', [
				'label' => esc_html__( 'Show Controls', 'vlthemes' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'vlthemes' ),
				'label_off' => esc_html__( 'No', 'vlthemes' ),
				'default' => 'no',
			]
		);

		$this->add_control(
			'video_width', [
				'label' => esc_html__( 'Video Width', 'vlthemes' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 640,
				],
				'separator' => 'before'
			]
		);

		$this->add_control(
			'video_height', [
				'label' => esc_html__( 'Video Height', 'vlthemes' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 360,
				],
			]
		);

		$this->end_controls_section();

		// ANCHOR
		$this->start_controls_section(
			'section_' . $first_level++, [
				'label' => esc_html__( 'Style', 'vlthemes' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'alignment', [
				'label' => esc_html__( 'Alignment', 'vlthemes' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'vlthemes' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'vlthemes' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'vlthemes' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};'
				],
			]
		);

		$this->add_control(
			'button_color', [
				'label' =>esc_html__( 'Color', 'vlthemes' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vlt-video-button' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		if ( empty( $settings[ 'video_url' ] ) ) {
			return;
		}

		switch ( $settings[ 'video_type' ] ) {

			case 'youtube':

			$prepend_url = add_query_arg( array(
				'autoplay' => $settings[ 'auto_play' ] == 'yes' ? 1 : 0,
				'loop' => $settings[ 'loop' ] == 'yes' ? 1 : 0,
				'controls' => $settings[ 'show_controls' ] == 'yes' ? 1 : 0,
				'mute' => $settings[ 'mute' ] == 'yes' ? 1 : 0,
				'start' => $settings[ 'start_time' ],
				'end' => $settings[ 'end_time' ],
				'showinfo' => 0
			), $settings[ 'video_url' ] );

			break;

			case 'vimeo':

			$prepend_url = add_query_arg( array(
				'autoplay' => $settings[ 'auto_play' ] == 'yes' ? 1 : 0,
				'loop' => $settings[ 'loop' ] == 'yes' ? 1 : 0,
				'controls' => $settings[ 'show_controls' ] == 'yes' ? 1 : 0,
				'muted' => $settings[ 'mute' ] == 'yes' ? 1 : 0,
			), $settings[ 'video_url' ] );

			break;
		}

		$this->add_render_attribute( 'video-button', [
			'class' => 'vlt-video-button',
		] );

		$this->add_render_attribute( 'video-button-link', [
			'data-fancybox' => '',
			'data-small-btn' => 'true',
			'data-width' => $settings[ 'video_width' ][ 'size' ],
			'data-height' => $settings[ 'video_height' ][ 'size' ],
			'data-caption' => $settings[ 'caption' ],
			'href' => $prepend_url,
			'rel' => 'nofollow'
		] );

		?>

		<div <?php echo $this->get_render_attribute_string( 'video-button' ); ?>>

			<a <?php echo $this->get_render_attribute_string( 'video-button-link' ); ?>>
				<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 27"><defs></defs><path fill="currentColor" d="M23.7471 13.2802L.876191 26.4847.876192.0757026 23.7471 13.2802z"></path></svg>
			</a>

		</div>

	<?php

	}

}