<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Widget_VLThemes_Timeline_Slider extends Widget_Base {

	public function get_name() {
		return 'vlt-timeline-slider';
	}

	public function get_title() {
		return esc_html__( 'Timeline Slider', 'vlthemes' );
	}

	public function get_icon() {
		return 'eicon-number-field vlthemes-badge';
	}

	public function get_categories() {
		return [ 'vlthemes-elements' ];
	}

	public function get_keywords() {
		return [ 'experience', 'timeline', 'slider' ];
	}

	protected function _register_controls() {

		$first_level = 0;

		// ANCHOR
		$this->start_controls_section(
			'section_' . $first_level++, [
				'label' => esc_html__( 'Timeline Slider', 'vlthemes' ),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'image', [
				'label' => esc_html__( 'Image', 'vlthemes' ),
				'type' => Controls_Manager::MEDIA,
			]
		);

		$repeater->add_control(
			'date', [
				'label' => esc_html__( 'Date', 'vlthemes' ),
				'type' => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'vlthemes' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true
			]
		);

		$repeater->add_control(
			'text', [
				'label' => esc_html__( 'Text', 'vlthemes' ),
				'type' => Controls_Manager::WYSIWYG,
				'label_block' => true,
			]
		);

		$this->add_control(
			'items', [
				'label' => esc_html__( 'Items', 'vlthemes' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ date }}}',
			]
		);

		$this->add_control(
			'navigation_anchor', [
				'label' => esc_html__( 'Navigation Anchor', 'vlthemes' ),
				'description' => esc_html__( 'Enter class / identifier that the navigation has.', 'vlthemes' ),
				'type' => Controls_Manager::TEXT,
				'separator' => 'before',
			]
		);

		$this->end_controls_section();

		// ANCHOR
		$this->start_controls_section(
			'section_' . $first_level++, [
				'label' => esc_html__( 'Settings', 'vlthemes' ),
				'tab' => Controls_Manager::TAB_SETTINGS,
			]
		);

		$this->add_control(
			'items_per_slide', [
				'label' => esc_html__( 'Items Per Slide', 'vlthemes' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 3,
			]
		);

		$this->end_controls_section();

		// ANCHOR
		$this->start_controls_section(
			'section_' . $first_level++, [
				'label' => esc_html__( 'Item Style', 'vlthemes' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'heading_' . $first_level++, [
				'label' => esc_html__( 'General', 'vlthemes' ),
				'type' => Controls_Manager::HEADING,
			]
		);

		$this->add_responsive_control(
			'item_padding', [
				'label' => esc_html__( 'Item Padding', 'vlthemes' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .vlt-timeline-item:not(:last-of-type)' => 'padding-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .vlt-timeline-item + .vlt-timeline-item' => 'padding-top: {{SIZE}}{{UNIT}};',
				]
			]
		);

		$this->add_control(
			'item_border_color', [
				'label' => esc_html__( 'Border Color', 'vlthemes' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vlt-timeline-item + .vlt-timeline-item' => 'border-top-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'heading_' . $first_level++, [
				'label' => esc_html__( 'Date', 'vlthemes' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), [
				'name' => 'date_typography',
				'selector' => '{{WRAPPER}} .vlt-timeline-item__date',
			]
		);

		$this->add_control(
			'date_color', [
				'label' => esc_html__( 'Text Color', 'vlthemes' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vlt-timeline-item__date' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'date_margin', [
				'label' => esc_html__( 'Margin', 'vlthemes' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', '%' ],
				'selectors' => [
					'{{WRAPPER}} .vlt-timeline-item__date' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_control(
			'heading_' . $first_level++, [
				'label' => esc_html__( 'Title', 'vlthemes' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), [
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .vlt-timeline-item__title',
			]
		);

		$this->add_control(
			'title_color', [
				'label' => esc_html__( 'Text Color', 'vlthemes' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vlt-timeline-item__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'heading_' . $first_level++, [
				'label' => esc_html__( 'Text', 'vlthemes' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), [
				'name' => 'text_typography',
				'selector' => '{{WRAPPER}} .vlt-timeline-item__text',
			]
		);

		$this->add_control(
			'text_color', [
				'label' => esc_html__( 'Text Color', 'vlthemes' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vlt-timeline-item__text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'text_margin', [
				'label' => esc_html__( 'Margin', 'vlthemes' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', '%' ],
				'selectors' => [
					'{{WRAPPER}} .vlt-timeline-item__text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( [
			'timeline-slider' => [
				'class' => 'vlt-timeline-slider',
				'data-navigation-anchor' => $settings[ 'navigation_anchor' ]
			]
		] );

		?>

		<div <?php echo $this->get_render_attribute_string( 'timeline-slider' ); ?>>

			<div class="swiper-container">

				<div class="swiper-wrapper">

					<?php

						$counter = 0;

						foreach ( $settings[ 'items' ] as $item ) {

							if ( $counter % $settings[ 'items_per_slide' ] == 0 ) {
								echo '<div class="swiper-slide">';
							}

							echo '<div class="vlt-timeline-item">';

								echo '<div class="row">';

									echo '<div class="col-xl-4">';

										echo wp_get_attachment_image( $item[ 'image' ][ 'id' ], 'full', false, [
											'loading' => 'lazy'
										] );

									echo '</div>';

									echo '<div class="col-xl-4">';

										if ( $item[ 'date' ] ) {
											echo '<div class="vlt-timeline-item__date">' . $item[ 'date' ] . '</div>';
										}

										if ( $item[ 'title' ] ) {
											echo '<h5 class="vlt-timeline-item__title">' . $item[ 'title' ] . '</h5>';
										}

									echo '</div>';

									echo '<div class="col-xl-4">';

										if ( $item[ 'text' ] ) {
											echo '<div class="vlt-timeline-item__text">' . $item[ 'text' ] . '</div>';
										}

									echo '</div>';

								echo '</div>';

							echo '</div>';

							if ( $counter % $settings[ 'items_per_slide' ] == $settings[ 'items_per_slide' ] - 1 ) {
								echo '</div>';
							}

							$counter++;

						}

					?>

				</div>

			</div>

		</div>

		<?php

	}

}