<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Widget_VLThemes_Partners extends Widget_Base {

	public function get_name() {
		return 'vlt-partners';
	}

	public function get_title() {
		return esc_html__( 'Partners', 'vlthemes' );
	}

	public function get_icon() {
		return 'eicon-logo vlthemes-badge';
	}

	public function get_categories() {
		return [ 'vlthemes-elements' ];
	}

	public function get_keywords() {
		return [ 'partners', 'logo', 'image' ];
	}

	protected function _register_controls() {

		$first_level = 0;

		// ANCHOR
		$this->start_controls_section(
			'section_' . $first_level++, [
				'label' => esc_html__( 'Partners', 'vlthemes' ),
			]
		);


		$this->add_control(
			'partners', [
				'label' => esc_html__( 'Partners', 'vlthemes' ),
				'type' => Controls_Manager::GALLERY,
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(), [
				'name' => 'partners', // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
			]
		);

		$this->end_controls_section();

	}

	public function render_partner_logo( $id, $instance ) {

		if ( ! empty( $id ) ) : ?>

			<li>

				<?php

					echo wp_get_attachment_image( $id, $instance[ 'partners_size' ], false, [
						'loading' => 'lazy'
					] );

				?>

			</li>

		<?php endif;

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'partners', 'class', 'vlt-partners' );

		$partners = wp_list_pluck( $settings[ 'partners' ], 'id' );

		?>

		<ul <?php echo $this->get_render_attribute_string( 'partners' ); ?>>

			<?php

				foreach ( $partners as $partner ) {
					$this->render_partner_logo( $partner, $settings );
				}

			?>

		</ul>

		<?php

	}

}