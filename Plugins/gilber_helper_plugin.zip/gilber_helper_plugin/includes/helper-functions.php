<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

/**
 * Share buttons
 */
if ( ! function_exists( 'vlthemes_get_post_share_buttons' ) ) {
	function vlthemes_get_post_share_buttons( $postID ) {
		$url = urlencode( get_permalink( $postID ) );
		$title = urlencode( get_the_title( $postID ) );
		$media = wp_get_attachment_image_src( get_post_thumbnail_id( $postID, 'full' ) );
		$output = '<a class="vlt-social-icon vlt-social-icon--style-1" title="' . esc_attr( 'Facebook', 'vlthemes' ) . '" target="_blank" href="https://www.facebook.com/share.php?u=' . $url . '&title=' . $title . '"><i class="lnir-facebook-filled"></i></a>';
		$output .= '<a class="vlt-social-icon vlt-social-icon--style-1" title="' . esc_attr( 'Twitter', 'vlthemes' ) . '" target="_blank" href="https://twitter.com/home?status=' . $title . '+' . $url . '"><i class="lnir-twitter-original"></i></a>';
		$output .= '<a class="vlt-social-icon vlt-social-icon--style-1" title="' . esc_attr( 'Pinterest', 'vlthemes' ) . '" target="_blank" href="https://pinterest.com/pin/create/button/?url=' . $url . '&media=' . $media[0] . '&description=' . $title . '"><i class="lnir-pinterest"></i></a>';
		$output .= '<a class="vlt-social-icon vlt-social-icon--style-1" title="' . esc_attr( 'LinkedIn', 'vlthemes' ) . '" target="_blank" href="https://www.linkedin.com/shareArticle?url='. $url . '&title=' . $title . '"><i class="lnir-linkedin-original"></i></a>';

		return apply_filters( 'vlthemes/get_post_share_buttons', $output );
	}
}