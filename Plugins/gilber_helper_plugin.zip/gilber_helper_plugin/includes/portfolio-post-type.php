<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

/**
 * Register portfolio post type
 */
if ( ! function_exists( 'vlthemes_portfolio_register_custom_post' ) ) {

	function vlthemes_portfolio_register_custom_post() {

		$labels = array(
			'name' => esc_html__( 'Portfolio', 'vlthemes' ),
			'singular_name' => esc_html__( 'Portfolio Item', 'vlthemes' ),
			'add_new' => esc_html__( 'Add New Portfolio Item', 'vlthemes' ),
			'add_new_item' => esc_html__( 'Add New Portfolio Item', 'vlthemes' ),
			'edit_item' => esc_html__( 'Edit Portfolio Item', 'vlthemes' ),
			'new_item' => esc_html__( 'New Portfolio Item', 'vlthemes' ),
			'view_item' => esc_html__( 'View Portfolio Item', 'vlthemes' ),
			'search_items' => esc_html__( 'Search Portfolio Items', 'vlthemes' ),
			'not_found' => esc_html__( 'No Portfolio Item Found', 'vlthemes' ),
			'not_found_in_trash' => esc_html__( 'No portfolio found in Trash', 'vlthemes' )
		);

		$args = array(
			'labels' => $labels,
			'hierarchical' => false,
			'public' => true,
			'show_ui' => true,
			'show_in_menu' => true,
			'menu_position' => 5,
			'menu_icon' => 'dashicons-screenoptions',
			'show_in_admin_bar' => true,
			'show_in_nav_menus' => true,
			'can_export' => true,
			'has_archive' => false,
			'exclude_from_search' => false,
			'publicly_queryable' => true,
			'rewrite' => false,
			'capability_type' => 'page',
			'supports' => [ 'title', 'editor', 'author', 'thumbnail', 'custom-fields', 'excerpt' ],
		);

		register_post_type( 'portfolio', $args );

	}

	add_action( 'init', 'vlthemes_portfolio_register_custom_post', 0 );

}

if ( ! function_exists( 'vlthemes_portfolio_custom_taxonomy' ) ) {

	function vlthemes_portfolio_custom_taxonomy() {

		$labels = array(
			'name' => _x( 'Portfolio Item Categories', 'Taxonomy General Name', 'vlthemes' ),
			'singular_name' => _x( 'Portfolio Item Category', 'Taxonomy Singular Name', 'vlthemes' ),
			'menu_name' => esc_html__( 'Portfolio Item Category', 'vlthemes' ),
			'all_items' => esc_html__( 'All Item Categories', 'vlthemes' ),
			'parent_item' => esc_html__( 'Parent Item', 'vlthemes' ),
			'parent_item_colon' => esc_html__( 'Parent Item:', 'vlthemes' ),
			'new_item_name' => esc_html__( 'New Item Category', 'vlthemes' ),
			'add_new_item' => esc_html__( 'Add New Item', 'vlthemes' ),
			'edit_item' => esc_html__( 'Edit Item', 'vlthemes' ),
			'update_item' => esc_html__( 'Update Item', 'vlthemes' ),
			'view_item' => esc_html__( 'View Item', 'vlthemes' ),
			'separate_items_with_commas' => esc_html__( 'Separate items with commas', 'vlthemes' ),
			'add_or_remove_items' => esc_html__( 'Add or remove items', 'vlthemes' ),
			'choose_from_most_used' => esc_html__( 'Choose from the most used', 'vlthemes' ),
			'popular_items' => esc_html__( 'Popular Items', 'vlthemes' ),
			'search_items' => esc_html__( 'Search Items', 'vlthemes' ),
			'not_found' => esc_html__( 'Not Found', 'vlthemes' ),
			'no_terms' => esc_html__( 'No items', 'vlthemes' ),
			'items_list' => esc_html__( 'Items list', 'vlthemes' ),
			'items_list_navigation' => esc_html__( 'Items list navigation', 'vlthemes' ),
		);

		$args = array(
			'labels' => $labels,
			'hierarchical' => true,
			'public' => true,
			'show_ui' => true,
			'show_admin_column' => true,
			'show_in_nav_menus' => true,
			'show_tagcloud' => true,
		);

		register_taxonomy( 'portfolio_category', array( 'portfolio' ), $args );

	}

	add_action( 'init', 'vlthemes_portfolio_custom_taxonomy', 0 );

}